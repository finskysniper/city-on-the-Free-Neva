public enum WeaponState
{
    Unequipped,
    Equipping,
    Equipped,
    Unequipping
}
