public enum WeaponClass
{
    Rifle,
    Pistol,
    Shotgun,
    SMG,
    Sniper
}
