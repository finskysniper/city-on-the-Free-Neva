public enum EquipSlot
{
    Item1,
    Item2,
    Armor
}
