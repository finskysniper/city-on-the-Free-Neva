public struct DamageData
{
    public int finalDamage;
    public bool isCritical;
}
