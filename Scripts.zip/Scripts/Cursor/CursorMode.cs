public enum CursorMode
{
    Movement,
    Interaction
}
